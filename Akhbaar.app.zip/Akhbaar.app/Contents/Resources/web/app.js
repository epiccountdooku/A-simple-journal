'use strict';
(() => {
  // ───────────────────────── helpers ─────────────────────────
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

  const hash = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
  const prng = (seed) => () => { seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

  // The paper-grain mask on the ink is a progressive enhancement: apply it only if a CORS-mode load
  // succeeds (which is exactly what CSS masks require), so the ink can never disappear.
  (() => {
    const probe = new Image();
    probe.crossOrigin = 'anonymous';
    probe.onload = () => document.documentElement.classList.add('mask-ok');
    probe.src = 'assets/ink-mask.png';
  })();

  // ───────────────────────── dates ─────────────────────────
  const pad = (n) => String(n).padStart(2, '0');
  const idOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const todayId = () => idOf(new Date());
  const dateOf = (id) => { const [y, m, d] = id.split('-').map(Number); return new Date(y, m - 1, d); };
  const parts = (id) => {
    const d = dateOf(id), f = (o) => d.toLocaleDateString('en-GB', o);
    return {
      weekday: f({ weekday: 'long' }), day: String(d.getDate()), month: f({ month: 'long' }), year: String(d.getFullYear()),
      short: `${f({ weekday: 'short' })} ${d.getDate()} ${f({ month: 'short' })}`,
      long: f({ weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }),
    };
  };

  // ───────────────────────── storage ─────────────────────────
  // Inside the app: one JSON file per date in ~/Library/Application Support/Akhbaar/Pages.
  // In a plain browser (development): localStorage.
  const Store = (() => {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.akhbaar;
    if (h) {
      return {
        native: true,
        async list() { return JSON.parse((await h.postMessage({ action: 'list' })) || '[]'); },
        save: (p) => h.postMessage({ action: 'save', id: p.id, data: JSON.stringify(p) }),
      };
    }
    const K = 'akhbaar.pages';
    const read = () => { try { return JSON.parse(localStorage.getItem(K) || '{}'); } catch { return {}; } };
    const write = (o) => { try { localStorage.setItem(K, JSON.stringify(o)); } catch {} };
    return {
      native: false,
      async list() { return Object.values(read()); },
      async save(p) { const o = read(); o[p.id] = p; write(o); },
    };
  })();

  // ───────────────────────── ink rendering ─────────────────────────
  // Text is drawn as one <span> per character so a freshly-typed letter can arrive wet and dry slowly,
  // and so we always know exactly where the nib should be.
  const isHigh = (c) => c >= 0xd800 && c < 0xdc00;
  const isLow = (c) => c >= 0xdc00 && c < 0xe000;

  class InkText {
    constructor(host) {
      this.host = host;
      this.spans = [];           // indexed by UTF-16 offset (a surrogate pair maps both offsets to one span)
      this.text = '';
      this.sel = [0, 0];
      this.end = el('span', 'c end');
      this.end.textContent = '​';
      host.textContent = '';
      host.appendChild(this.end);
    }
    get length() { return this.text.length; }
    _mk(cp, wet) {
      const s = el('span', wet ? 'c wet' : 'c');
      s.textContent = cp;
      s.style.cssText = `--o:${(0.9 + Math.random() * 0.1).toFixed(3)};--j:${((Math.random() - 0.5) * 0.9).toFixed(2)}px`;
      return s;
    }
    splice(start, del, ins, wet) {
      this.setSelection(0, 0);
      for (let i = start; i < start + del; i++) this.spans[i] && this.spans[i].remove();
      const ref = this.spans[start + del] || this.end;
      const frag = document.createDocumentFragment(), entries = [];
      for (const cp of ins) {
        const s = this._mk(cp, wet);
        frag.appendChild(s);
        entries.push(s);
        if (cp.length === 2) entries.push(s);
      }
      this.host.insertBefore(frag, ref);
      this.spans.splice(start, del, ...entries);
      this.text = this.text.slice(0, start) + ins + this.text.slice(start + del);
    }
    set(text, wet = false) { this.splice(0, this.text.length, text, wet); }
    setSelection(a, b) {
      const [oa, ob] = this.sel;
      for (let i = oa; i < ob; i++) this.spans[i] && this.spans[i].classList.remove('sel');
      for (let i = a; i < b; i++) this.spans[i] && this.spans[i].classList.add('sel');
      this.sel = [a, b];
    }
    // Viewport position of the gap before character i.
    rectAt(i) {
      const s = this.spans[i] || this.end;
      const r = s.getClientRects()[0];
      if (r && r.height > 0) return { left: r.left, top: r.top, height: r.height };
      const p = i > 0 && this.spans[i - 1] && this.spans[i - 1].getClientRects()[0];
      if (p && p.height > 0) return { left: p.right, top: p.top, height: p.height };
      const h = this.host.getBoundingClientRect();
      return { left: h.left, top: h.top, height: parseFloat(getComputedStyle(this.host).lineHeight) || 30 };
    }
    width() { return this.rectAt(this.length).left - this.rectAt(0).left; }
  }

  let activeField = null;
  const pageView = () => $('#page');

  function revealCaret(r) {
    const view = pageView();
    const bottom = innerHeight - 120, top = 90;
    if (r.top + r.height > bottom) view.scrollTop += r.top + r.height - bottom;
    else if (r.top < top) view.scrollTop -= top - r.top;
  }

  class InkField {
    constructor(host, { multiline = true, placeholder = '', onChange = () => {}, onEnter = null, label = '' } = {}) {
      host.replaceChildren();
      host.classList.add('ink-field');
      Object.assign(this, { host, multiline, onChange, onEnter, last: '', lastSel: [-1, -1, ''], timer: 0 });
      this.mirror = el('div', 'mirror');
      this.mirror.setAttribute('aria-hidden', 'true');
      this.ink = new InkText(this.mirror);
      this.ph = el('div', 'ph');
      this.ph.textContent = placeholder;
      const ta = (this.ta = el('textarea'));
      ta.rows = 1;
      ta.spellcheck = false;
      ta.setAttribute('autocomplete', 'off');
      ta.setAttribute('autocapitalize', 'off');
      ta.setAttribute('aria-label', label);
      host.append(this.mirror, this.ph, ta);
      ta.addEventListener('input', () => this._input());
      ta.addEventListener('keydown', (e) => this._key(e));
      ta.addEventListener('focus', () => this._focus());
      ta.addEventListener('blur', () => this._blur());
      ta.addEventListener('mouseup', () => this.sync());
    }
    get value() { return this.last; }
    load(v) {
      this.ta.value = v;
      this.ink.set(v, false);
      this.last = v;
      this._flag();
    }
    _flag() { this.host.classList.toggle('has-text', this.last.length > 0); }
    _input() {
      const ta = this.ta;
      let v = ta.value;
      if (!this.multiline && /\n/.test(v)) {
        const pos = ta.selectionStart;
        v = v.replace(/\s*\n+\s*/g, ' ');
        ta.value = v;
        ta.setSelectionRange(pos, pos);
      }
      const prev = this.last, max = Math.min(prev.length, v.length);
      let p = 0, s = 0;
      while (p < max && prev.charCodeAt(p) === v.charCodeAt(p)) p++;
      if (p > 0 && isHigh(v.charCodeAt(p - 1))) p--;
      while (s < max - p && prev.charCodeAt(prev.length - 1 - s) === v.charCodeAt(v.length - 1 - s)) s++;
      if (s > 0 && isLow(v.charCodeAt(v.length - s))) s--;
      this.ink.splice(p, prev.length - p - s, v.slice(p, v.length - s), true);
      this.last = v;
      this._flag();
      Quill.nudge();
      this.sync(true);
      this.onChange(v);
    }
    _key(e) {
      if (e.key === 'Enter' && !this.multiline && !e.isComposing) {
        e.preventDefault();
        if (this.onEnter) this.onEnter();
      }
    }
    _focus() {
      activeField = this;
      clearInterval(this.timer);
      this.timer = setInterval(() => this.sync(), 60);   // catches arrow keys, drags, select-all…
      Quill.show();
      this.sync(true);
    }
    _blur() {
      clearInterval(this.timer);
      this.ink.setSelection(0, 0);
      this.lastSel = [-1, -1, ''];
      if (activeField === this) { activeField = null; Quill.hide(); }
    }
    sync(force) {
      const t = this.ta;
      if (document.activeElement !== t) return;
      const a = t.selectionStart, b = t.selectionEnd, d = t.selectionDirection, L = this.lastSel;
      if (!force && a === L[0] && b === L[1] && d === L[2]) return;
      this.lastSel = [a, b, d];
      this.ink.setSelection(a, b);
      this.placeQuill(true);
    }
    placeQuill(reveal) {
      const t = this.ta;
      const i = t.selectionDirection === 'backward' ? t.selectionStart : t.selectionEnd;
      const r = this.ink.rectAt(i);
      Quill.moveTo(r.left, r.top + r.height * 0.8);
      if (reveal) revealCaret(r);
    }
    focus(atEnd = true) {
      this.ta.focus({ preventScroll: true });
      if (atEnd) this.ta.setSelectionRange(this.last.length, this.last.length);
    }
    blur() { this.ta.blur(); }
  }

  // The quill "writes" text that nobody typed (the date, the title): one letter at a time.
  let skipScribe = false;
  async function scribe(ink, text, { speed = 1, centered = false, token = null } = {}) {
    const host = ink.host;
    const cancelled = () => skipScribe || (token !== null && token !== runToken);
    if (centered) {              // fix the start so the line doesn't re-centre with every letter
      ink.set(text);
      const w = ink.width();
      ink.set('');
      host.style.textAlign = 'left';
      host.style.paddingLeft = Math.max(0, (host.clientWidth - w) / 2) + 'px';
    }
    let i = 0;
    for (const ch of text) {
      if (cancelled()) break;
      ink.splice(ink.length, 0, ch, true);
      const r = ink.rectAt(ink.length);
      Quill.moveTo(r.left, r.top + r.height * 0.8);
      Quill.nudge();
      i++;
      await sleep((62 + Math.random() * 58) * speed * (ch === ' ' ? 1.7 : 1));
    }
    if (i < [...text].length) ink.set(text);
    if (centered) { host.style.textAlign = ''; host.style.paddingLeft = ''; }
  }

  // ───────────────────────── the hand-drawn date box ─────────────────────────
  const BOX_W = 176, BOX_H = 168;
  function boxPath(seed) {
    const r = prng(hash(seed)), j = (a) => (r() - 0.5) * a;
    const P = (x, y) => [x + j(3.2), y + j(3.2)];
    const tl = P(8, 9), tr = P(BOX_W - 8, 8), br = P(BOX_W - 7, BOX_H - 9), bl = P(9, BOX_H - 8);
    const bow = (a, b, amt) => {
      const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy);
      return [(a[0] + b[0]) / 2 - (dy / l) * amt, (a[1] + b[1]) / 2 + (dx / l) * amt];
    };
    const f = (p) => `${p[0].toFixed(1)} ${p[1].toFixed(1)}`;
    const start = [tl[0] - 5, tl[1] + 1 + j(2)];
    const end = [tl[0] + j(2), tl[1] - 6 - r() * 4];          // the pen overshoots the corner where it started
    return `M${f(start)} Q${f(bow(start, tr, j(5)))} ${f(tr)} Q${f(bow(tr, br, j(5)))} ${f(br)} Q${f(bow(br, bl, j(5)))} ${f(bl)} Q${f(bow(bl, end, j(5)))} ${f(end)}`;
  }
  const boxSVG = (id) =>
    `<svg viewBox="0 0 ${BOX_W} ${BOX_H}" aria-hidden="true"><path class="p2" d="${boxPath(id + 'b')}"/><path class="p1" d="${boxPath(id)}"/></svg>`;

  function drawBox(svg, ms, token) {
    return new Promise((done) => {
      const p1 = svg.querySelector('.p1'), p2 = svg.querySelector('.p2');
      const L1 = p1.getTotalLength(), L2 = p2.getTotalLength();
      const clear = () => { for (const p of [p1, p2]) { p.style.strokeDasharray = ''; p.style.strokeDashoffset = ''; } };
      p1.style.strokeDasharray = L1; p1.style.strokeDashoffset = L1;
      p2.style.strokeDasharray = L2; p2.style.strokeDashoffset = L2;
      const t0 = performance.now();
      let lastNudge = 0;
      const frame = (now) => {
        if (skipScribe || token !== runToken) { clear(); return done(); }
        const k = Math.min(1, (now - t0) / ms);
        const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        p1.style.strokeDashoffset = L1 * (1 - e);
        p2.style.strokeDashoffset = L2 * (1 - e);
        const pt = p1.getPointAtLength(L1 * e), m = p1.getScreenCTM();
        Quill.moveTo(m.a * pt.x + m.c * pt.y + m.e, m.b * pt.x + m.d * pt.y + m.f);
        if (now - lastNudge > 130) { Quill.nudge(); lastNudge = now; }
        if (k < 1) requestAnimationFrame(frame); else { clear(); done(); }
      };
      requestAnimationFrame(frame);
    });
  }

  // ───────────────────────── state ─────────────────────────
  const pages = new Map();       // id (YYYY-MM-DD) → { id, heading, body, created, updated } — one page per date
  let cur = null;                // the page being written
  let curFields = null;          // { heading, body }
  let dirty = false, saveTimer = 0;
  let runToken = 0;              // bumps whenever the page changes; stale animations stop themselves

  const allIds = () => { const s = new Set(pages.keys()); if (cur) s.add(cur.id); return [...s].sort(); };   // oldest → newest
  const hasToday = () => pages.has(todayId()) || (!!cur && cur.id === todayId());

  async function flush() {
    clearTimeout(saveTimer);
    if (!dirty || !cur) return;
    dirty = false;
    cur.updated = new Date().toISOString();
    pages.set(cur.id, cur);
    try { await Store.save(cur); } catch (err) { console.error('save failed', err); dirty = true; }
  }
  function scheduleSave() {
    if (!cur) return;
    dirty = true;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(flush, 450);
  }

  // ───────────────────────── the new-page button ─────────────────────────
  let hintTimer = 0;
  function hint(msg) {
    const h = $('#hint');
    h.textContent = msg;
    h.classList.add('show');
    clearTimeout(hintTimer);
    hintTimer = setTimeout(() => h.classList.remove('show'), 3000);
  }
  function syncButton() {
    $('#newpage').classList.toggle('fresh', !hasToday());     // invites a new page when today has none
  }
  async function newPage() {
    if (cur && cur.id === todayId()) {      // already on today's page: one page per date, no more
      hint('One page for each day — today’s is already here.');
      const b = $('#newpage');
      b.classList.remove('nope');
      void b.offsetWidth;
      b.classList.add('nope');
      if (curFields) curFields.body.focus(true);
      return;
    }
    await openPage(todayId());              // opens today's page, or starts a fresh one
  }

  // ───────────────────────── a page ─────────────────────────
  function turnPage() {
    const v = $('#page');
    v.classList.remove('enter');
    void v.offsetWidth;
    if (!reduceMotion) v.classList.add('enter');
    v.scrollTop = 0;
  }

  async function openPage(id) {
    await flush();
    const token = ++runToken;
    skipScribe = false;
    if (activeField) activeField.blur();
    Quill.hide();
    const existing = pages.get(id);
    cur = existing || { id, heading: '', body: '', created: new Date().toISOString(), updated: '' };
    dirty = false;
    const pr = parts(id);

    // date box
    const db = $('#datebox');
    db.innerHTML = boxSVG(id);
    const mk = (cls) => { const d = el('div', `dl ink-text ${cls}`); db.appendChild(d); return new InkText(d); };
    const wk = mk('wk'), dn = mk('dn'), my = mk('my');
    const lines = [[wk, pr.weekday], [dn, pr.day], [my, `${pr.month} ${pr.year}`]];

    // heading + body, filled in by the writer
    const body = new InkField($('#body'), { placeholder: 'Begin writing…', label: 'Page text', onChange: (v) => { cur.body = v; scheduleSave(); } });
    const heading = new InkField($('#heading'), {
      multiline: false, placeholder: 'A heading for the day…', label: 'Heading',
      onChange: (v) => { cur.heading = v; scheduleSave(); },
      onEnter: () => body.focus(false),
    });
    heading.load(cur.heading);
    body.load(cur.body);
    curFields = { heading, body };
    turnPage();
    syncButton();

    if (!existing && !reduceMotion) {
      // A fresh page: the quill draws the box and writes the date. Typing (or a click) cuts it short.
      const stop = (e) => {
        skipScribe = true;
        if (e.type === 'keydown' && !e.metaKey && !e.ctrlKey && !e.altKey && e.key.length === 1) heading.focus(false);
      };
      addEventListener('keydown', stop, true);
      addEventListener('pointerdown', stop, true);
      await sleep(380);
      if (token === runToken) {
        Quill.show();
        await drawBox($('svg', db), 760, token);
        await sleep(60);
        for (const [ink, text] of lines) {
          if (token !== runToken) break;
          await scribe(ink, text, { centered: true, token, speed: ink === dn ? 1.5 : 0.9 });
        }
      }
      removeEventListener('keydown', stop, true);
      removeEventListener('pointerdown', stop, true);
      if (token !== runToken) return;
      for (const [ink, text] of lines) if (ink.text !== text) ink.set(text);
      skipScribe = false;
    } else {
      for (const [ink, text] of lines) ink.set(text);
    }
    if (token !== runToken) return;
    if (activeField) return;                 // the writer already started typing
    if (!cur.heading) heading.focus();
    else body.focus(true);
  }

  function step(dir) {            // dir -1 → older page, +1 → newer page
    if (!cur) return;
    const ids = allIds(), n = ids[ids.indexOf(cur.id) + dir];
    if (n) openPage(n);
  }

  // ───────────────────────── wiring ─────────────────────────
  $('#newpage').addEventListener('click', newPage);
  $('#ink').addEventListener('mousedown', (e) => {         // clicking the margins puts the pen on the page
    if (e.target.closest('textarea') || !curFields) return;
    e.preventDefault();
    curFields.body.focus(true);
  });
  $('#page').addEventListener('scroll', () => activeField && activeField.placeQuill(false), { passive: true });
  addEventListener('resize', () => activeField && activeField.placeQuill(false));
  addEventListener('focus', syncButton);                    // the date may have rolled over while it sat open
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); else syncButton(); });
  addEventListener('pagehide', () => { flush(); });

  // Hooks used by the native menu and the quit handler.
  window.Akhbaar = { flush, newPage, older: () => step(-1), newer: () => step(1) };

  (async () => {
    try { for (const p of await Store.list()) if (p && p.id) pages.set(p.id, p); } catch (err) { console.error(err); }
    const latest = [...pages.keys()].sort().pop();
    await openPage(latest || todayId());     // straight to writing: where you left off, or today on first launch
  })();
})();
