'use strict';
// The quill: a terracotta feather whose nib sits on the insertion point.
// buildQuillSVG() is also used by tools/icon.html for the app icon.

function buildQuillSVG() {
  // Axis runs from the nib (bottom-left) up to the feather tip (top-right).
  const x0 = 6, y0 = 112, x1 = 80, y1 = 6;
  const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy);
  const ux = dx / L, uy = dy / L;      // along the shaft
  const nx = -uy, ny = ux;             // normal: +n is lower-right, -n is upper-left
  const BEND = 7;                      // a feather curls away from its shaft's straight line
  const at = (t, off) => [x0 + dx * t + nx * (off + BEND * Math.sin(Math.PI * t) * t), y0 + dy * t + ny * (off + BEND * Math.sin(Math.PI * t) * t)];
  const f = (p) => `${p[0].toFixed(2)},${p[1].toFixed(2)}`;

  const t0 = 0.27, steps = 30;
  const profile = (s) => Math.pow(Math.sin(Math.PI * Math.pow(s, 0.74)), 0.9);
  const WL = 13.5, WR = 8.2;          // asymmetric vane, like a real flight feather

  const left = [], right = [], barbs = [];
  for (let k = 0; k <= steps; k++) {
    const s = k / steps, t = t0 + s * (1 - t0), pr = profile(s);
    const notch = k % 2 ? 2.1 : 0;     // ragged barb ends
    const slit = k === 13 || k === 14 ? 5 : 0;
    left.push(at(t, -(WL * pr - notch * pr - slit * pr)));
    right.push(at(t, WR * pr - notch * 0.8 * pr));
    if (k > 0 && k < steps && k % 2 === 0) {
      const c = at(t, 0);
      // barbs sweep toward the tip
      const lt = at(Math.min(1, t + 0.05), -(WL * pr * 0.92));
      const rt = at(Math.min(1, t + 0.05), WR * pr * 0.92);
      barbs.push(`M${f(c)}L${f(lt)}`, `M${f(c)}L${f(rt)}`);
    }
  }
  const vane = 'M' + left.map(f).join('L') + 'L' + right.reverse().map(f).join('L') + 'Z';
  const shaftPts = [];
  for (let k = 0; k <= 16; k++) shaftPts.push(at(0.99 * (k / 16), 0));
  const shaft = 'M' + shaftPts.map(f).join('L');
  const nibA = at(0.27, -2.4), nibB = at(0.27, 2.4);
  const nib = `M${x0},${y0}L${f(nibA)}L${f(nibB)}Z`;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 86 118" width="86" height="118" overflow="visible">
    <path d="${vane}" fill="var(--quill)"/>
    <path d="${barbs.join('')}" stroke="rgba(255,236,220,.5)" stroke-width=".75" stroke-linecap="round" fill="none"/>
    <path d="${vane}" fill="none" stroke="var(--quill-dark)" stroke-width=".6" stroke-opacity=".55" stroke-linejoin="round"/>
    <path d="${shaft}" stroke="var(--quill-dark)" stroke-width="1.9" stroke-linecap="round" fill="none"/>
    <path d="${nib}" fill="var(--quill-dark)"/>
    <circle cx="${x0 + 0.6}" cy="${y0 - 0.4}" r="1.7" fill="var(--ink)"/>
  </svg>`;
}

const Quill = (() => {
  const SCALE = 1.08;
  const TIP = { x: 6 * SCALE, y: 112 * SCALE };
  const el = document.getElementById('quill');
  if (!el) return { moveTo() {}, nudge() {}, show() {}, hide() {}, rest() {} };

  const inner = el.querySelector('.q-inner');
  inner.innerHTML = buildQuillSVG();
  el.style.width = `${86 * SCALE}px`;
  el.style.height = `${118 * SCALE}px`;
  inner.style.transformOrigin = `${TIP.x}px ${TIP.y}px`;
  inner.firstElementChild.style.cssText = `width:100%;height:100%;display:block`;

  let writeTimer = 0, idleTimer = 0, flip = false, placed = false;

  function moveTo(x, y) {
    if (!placed) {              // first placement shouldn't glide in from the corner
      el.style.transition = 'none';
      requestAnimationFrame(() => (el.style.transition = ''));
      placed = true;
    }
    el.style.transform = `translate3d(${(x - TIP.x).toFixed(1)}px, ${(y - TIP.y).toFixed(1)}px, 0)`;
  }
  function wake() {
    el.classList.add('on');
    el.classList.remove('idle');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => el.classList.add('idle'), 2400);
  }
  function nudge() {            // one keystroke / one pen stroke
    wake();
    el.classList.add('writing');
    // alternate two animation names so every keystroke restarts the little dip
    inner.classList.toggle('dip-a', (flip = !flip));
    inner.classList.toggle('dip-b', !flip);
    clearTimeout(writeTimer);
    writeTimer = setTimeout(() => el.classList.remove('writing'), 420);
  }
  function show() { wake(); }
  function hide() {
    clearTimeout(idleTimer);
    el.classList.remove('on', 'idle', 'writing');
    placed = false;
  }
  return { moveTo, nudge, show, hide };
})();
